//
//  IJIMNews.h
//  Jimu
//
//  Created by 冯鸿杰 on 17/2/10.
//  Copyright © 2017年 Mob. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IMOBFDataModel.h"

/**
 文章信息协议
 */
@protocol IMOBFArticle <IMOBFDataModel>

@end
