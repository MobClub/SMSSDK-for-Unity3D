//
//  SMSSDKUIContactFriendsViewController.h
//  SMSSDKUI
//
//  Created by youzu_Max on 2017/6/7.
//  Copyright © 2017年 youzu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SMSSDKUIContactFriendsViewController : UIViewController

- (instancetype)initWithContactFriends:(NSArray *)contactFriends;

@end
